//imagens
let imagemDaEstrada;
let imagemDoMascote;
let imagemDoCarro1;
let imagemDoCarro2;
let imagemDoCarro3;

let imagensCarros;


function preload() {
    imagemDaEstrada = loadImage("img/estrada.png");
    imagemDoMascote = loadImage("img/mascote.png");
    imagemDoCarro1 = loadImage("img/carro-1.png");
    imagemDoCarro2 = loadImage("img/carro-2.png");
    imagemDoCarro3 = loadImage("img/carro-3.png");

    imagensCarros = [imagemDoCarro1, imagemDoCarro2, imagemDoCarro3, imagemDoCarro1, imagemDoCarro2, imagemDoCarro3];
}



