//CADASTRO DE CLIENTE

let clientes = [];

function Cadastro(cpf, email, senha, confirmarSenha, telefone) {
    if (cpf.length !== 11 || !/^\d+$/.test(cpf)) {
        console.log("Erro! Por favor, insira um CPF válido com 11 dígitos numéricos.");
        return;
    }

    if (!email.includes("@")) {
        console.log("E-mail inválido");
        return;
    }

    if (senha.length <= 7 || !/[!@#$%^&*()_+={}\[\]:;<>,.?/~\\-]/.test(senha)) {
        console.log("Por favor, digite uma senha com mais de 7 caracteres e utilize pelo menos 1 caractere especial.");
        return;
    }

    if (senha !== confirmarSenha) {
        console.log("As senhas não coincidem");
        return;
    }

    if (telefone.length !== 11 || !/^\d+$/.test(telefone)) {
        console.log("Por favor, digite seu número de telefone corretamente");
        return;
    }

    const novoCliente = { cpf, email, senha, telefone };
    clientes.push(novoCliente);
    console.log("Cadastro realizado com sucesso", novoCliente);
}


//LOGIN DE CLIENTE

function login(email, senha) {
    if (clientes.length === 0) {
        console.log("Erro! Nenhum usuário cadastrado.");
        return;
    }

    const usuario = clientes.find((usuario) => usuario.email === email);

    if (!usuario) {
        console.log("Usuário não encontrado. Verifique o email.");
        return;
    }

    if (usuario.senha === senha) {
        console.log("Login bem-sucedido!");
    } else {
        console.log("Senha incorreta. Tente novamente.");
    }
}

// EXEMPLO PARA USO
Cadastro("12345678901", "brunogomes@gmail.com", "bruno@2023", "bruno@2023", "11950473525");
login("brunogomes@gmail.com", "bruno@2023");

console.log(clientes);


//FILTRO DE PIZZAS

const pizzas = [
    { nome: 'Pizza do Tonhão', preco: 65.90 },
    { nome: 'Calabresa', preco: 45.00 },
    { nome: 'Pepperoni', preco: 24.99 },
    { nome: 'Mussarela', preco: 29.90 },
    { nome: 'Portuguesa', preco: 31.90 }
];

function procuraPizza(termo) {
    const numero = !isNaN(parseFloat(termo)) && isFinite(termo);
    
    const LowerCase = termo.toLowerCase();
    
    const pizzasFiltradas = pizzas.filter(pizza => {
        if (numero) {
            return pizza.preco == termo;
        } else {
            return pizza.nome.toLowerCase().includes(LowerCase);
        }
    });
    
    return pizzasFiltradas;
}

//EXEMPLO PARA USO
console.log(procuraPizza('Pizza do Tonhão'));  


//FILTRO INFORMAÇÕES DO PERFIL

function imprimirInfo(nome, telefone, email, endereco) {
    console.log(`Usuário: ${nome}, Telefone: ${telefone}, Email: ${email}, Endereço: ${endereco}`);
}

const nome = "Bruno Gomes";
const telefone = "11950473525";
const email = "brunogomes@gmail.com";
const endereco = "Rua Não sei o que não sei o que lá, 157";

imprimirInfo(nome, telefone, email, endereco);