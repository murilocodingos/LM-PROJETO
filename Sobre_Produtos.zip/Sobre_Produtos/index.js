import React, { useState, useEffect } from 'react';
import headerLogo from '../img/header_logo.svg';
import shoppingCart from '../img/shopping-cart.svg';
import productDoce from '../img/product-doce.png';
import productCookie from '../img/product-cookie.png';
import productAvela from '../img/product-avela.png';

  return (
    <div className="carousel">
      <div className="container">
        <header className="header-home d-flex justify-content-between align-items-center">
          <img src={headerLogo} alt="Logo" width="75px" />
          <nav className="sobre-produtos-navbar d-flex align-items-center">
            <ul className="d-flex gap-4 list-unstyled mb-0" id="ul-itens">
              <a href="#" className="a-home"><li className="li-front">Home</li></a>
              <a href="#" className="a-home"><li className="li-front">Produtos</li></a>
              <a href="#" className="a-home"><li className="li-front">Sobre</li></a>
            </ul>
            <div className="button-container d-flex ms-5" id="button-container">
              <a href="#" className="button-text" id="login-text"><div className="login-button">Login</div></a>
              <a href="#" className="button-text" id="cadastrar-text"><div className="cadastrar-button">Cadastre-se</div></a>
            </div>
            <a href="#"><div className="cart-img ms-3"><img src={shoppingCart} alt="Cart" width="30px" /></div></a>
            <div className="burger-icon">
              <label className="burger" htmlFor="burger">
                <input className="line" type="checkbox" id="burger" />
              </label>
            </div>
          </nav>
        </header>
      </div>
      <div className={`list ${carouselClass}`}>
        {items.map((item, index) => (
          <div className="item" key={index}>
            <img src={item.img} alt={item.title} />
            <div className="introduce">
              <div className="title">{item.title}</div>
              <div className="topic">{item.topic}</div>
              <button className="home-button">Saiba Mais</button>
            </div>
          </div>
        ))}
      </div>
      <div className="arrows">
        <button id="prev" onClick={() => showSlider('prev')}>{'<'}</button>
        <button id="next" onClick={() => showSlider('next')}>{'>'}</button>
      </div>
    </div>
  );

export default Home;