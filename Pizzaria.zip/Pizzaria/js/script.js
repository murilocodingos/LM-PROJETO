var button = document.getElementById('myButton');
var isToggled = false;

button.addEventListener('click', function() {
  isToggled = !isToggled;
  updateButtonState();
});

function updateButtonState() {
  if (isToggled) {
    button.classList.add('active');
  } else {
    button.classList.remove('active');
  }
}
