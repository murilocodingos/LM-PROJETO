<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Biblioteca Municipal</title>
    </head>
    <body>
        <header>
            <img src="/img/Biblioteca-Banner.png" alt="Biblioteca-Banner">
            <nav>
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="usuarios.php">Usuários</a></li>
                    <li><a href="#">Livros</a></li>
                    <li><a href="#">Emprestimos</a></li>
                </ul>
            </nav>
        </header>
        <main>
            

        </main>
    </body>
</html>