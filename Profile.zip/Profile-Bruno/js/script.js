function mode() {
    
    const html = document.documentElement

    html.classList.mode()
}